<?php
@file_put_contents('d.json',@file_get_contents('http://service.mazanex.com/lastsecond.json'),$rates);
